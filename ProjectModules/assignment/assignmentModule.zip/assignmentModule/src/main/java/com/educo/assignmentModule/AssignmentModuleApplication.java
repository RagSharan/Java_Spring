package com.educo.assignmentModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentModuleApplication.class, args);
	}
}
