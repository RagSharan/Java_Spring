package com.educo.resultModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResultModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResultModuleApplication.class, args);
	}
}
