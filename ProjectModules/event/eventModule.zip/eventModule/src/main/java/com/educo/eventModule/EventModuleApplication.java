package com.educo.eventModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventModuleApplication.class, args);
	}
}
