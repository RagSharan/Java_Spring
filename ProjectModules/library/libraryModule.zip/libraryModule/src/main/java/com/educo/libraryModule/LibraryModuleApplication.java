package com.educo.libraryModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryModuleApplication.class, args);
	}
}
