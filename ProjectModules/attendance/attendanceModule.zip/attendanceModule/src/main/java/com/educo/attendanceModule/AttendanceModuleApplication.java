package com.educo.attendanceModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceModuleApplication.class, args);
	}
}
