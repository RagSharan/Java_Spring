package com.educo.examModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamModuleApplication.class, args);
	}
}
